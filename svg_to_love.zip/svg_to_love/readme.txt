https://css-tricks.com/rendering-svg-paths-in-webgl/
